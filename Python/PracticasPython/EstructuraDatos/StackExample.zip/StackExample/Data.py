from Book import Book

book1 = Book("Don Quijote", "Miguel De Cervantes", "Norma", 2004)
book2 = Book("Bajo La Misma Estrella", "Jhon Green", "Norma", 2012)
book3 = Book("After", "Anna Todd", "Norma", 2014)
book4 = Book("La Divina Comedia", "Dante Alighieri", "Norma", 1320)
book5 = Book("Cien Años De Soledad", "Gabriel Garcia Marquez", "Norma", 1967)
book6 = Book("Romeo Y Julieta", "William Shakespeare", "Norma", 1597)
book7 = Book("Harry Potter", "J. K. Rowling", "Norma", 1998)
book8 = Book("Narnia", "C. S. Lewis", "Norma", 1950)
book9 = Book("La Metamorfosis", "Franz Kafka", "Norma", 1915)
book10 = Book("Juego De Tronos", "George R. R. Martin", "Norma", 1996)