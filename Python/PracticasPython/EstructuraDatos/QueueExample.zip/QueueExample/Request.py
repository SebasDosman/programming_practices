from enum import Enum

class Request(Enum):
    PENDING = 1
    SUCCESSFUL = 2