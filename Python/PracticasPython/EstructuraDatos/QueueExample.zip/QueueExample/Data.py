from User import User
from Request import Request

user1 = User("Carlos", "Betancur", 28, 123, Request.PENDING)
user2 = User("Maria", "Benavides", 21, 456, Request.PENDING)
user3 = User("Segundo", "Cruz", 27, 789, Request.PENDING)
user4 = User("Jurgen", "Sanclemente", 26, 101, Request.PENDING)
user5 = User("Mauro", "Bonilla", 21, 121, Request.PENDING)
user6 = User("Mariana", "Ramos", 22, 141, Request.PENDING)
user7 = User("Camilo", "Beltran", 19, 161, Request.PENDING)
user8 = User("Mario", "Lizaraso", 23, 181, Request.PENDING)
user9 = User("Daniela", "Cardona", 25, 221, Request.PENDING)
user10 = User("Paula", "Veracruz", 21, 241, Request.PENDING)